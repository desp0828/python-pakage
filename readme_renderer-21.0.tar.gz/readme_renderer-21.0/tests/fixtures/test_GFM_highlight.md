This is normal text.

```
This is code text.
```

```python
def this_is_python():
    pass
```

```go
func ThisIsGo(){
    return
}
```

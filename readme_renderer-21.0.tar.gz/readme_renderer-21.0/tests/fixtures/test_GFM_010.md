This ~text~~~~ is ~~~~curious~.

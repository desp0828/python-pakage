<div id="required-packages">
<h2>Required packages</h2>
<p>To run the PyPI software, you need Python 2.5+ and PostgreSQL</p>
</div>
<div id="quick-development-setup">
<h2>Quick development setup</h2>
<p>Make sure you are sitting</p>
</div>

This is normal text.

```
This is code text.
```

```python
def this_is_python():
    """This is a docstring."""
    pass
```

```go
func ThisIsGo(){
    return
}
```

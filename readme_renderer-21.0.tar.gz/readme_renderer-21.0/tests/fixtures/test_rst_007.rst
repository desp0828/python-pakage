Something naughty this way comes
<script>
    alert("Hello");
</script>

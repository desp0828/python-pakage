#ifndef CMARK_VERSION_H
#define CMARK_VERSION_H

#define CMARK_VERSION ((0 << 24) | (28 << 16) | (3 << 8) | 12)
#define CMARK_VERSION_STRING "0.28.3.gfm.12"
#define CMARK_GFM_VERSION 12

#endif

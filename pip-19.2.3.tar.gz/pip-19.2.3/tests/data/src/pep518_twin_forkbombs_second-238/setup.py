from setuptools import setup

setup(name='pep518_twin_forkbombs_second',
      version='238',
      py_modules=['pep518_twin_forkbombs_second'])

# -*- coding: latin-1 -*-

from distutils.core import setup

setup(name="SetupPyUTF8",
      author=u"Sa�l Ibarra Corretg�",
      )

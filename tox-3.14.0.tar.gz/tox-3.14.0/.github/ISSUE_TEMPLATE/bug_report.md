---
name: Bug report
about: Something that does not works as expected
title: ""
labels: bug:normal
assignees: ''

---

When submitting a bug make sure you can reproduce it via ``tox -rvv`` and attach the output of that to the bug. Ideally, you should also submit a project that allows easily reproducing the bug. Thanks!

"""This is here because mypy doesn't understand PEP 420."""

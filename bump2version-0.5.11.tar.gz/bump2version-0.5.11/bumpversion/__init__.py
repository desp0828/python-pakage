__version__ = "0.5.11"
__license__ = "MIT"
__title__ = "bumpversion"

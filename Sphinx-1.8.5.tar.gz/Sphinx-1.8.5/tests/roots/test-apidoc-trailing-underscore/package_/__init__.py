""" A package with trailing underscores """

default_role
============

.. default-role:: pep

`8`

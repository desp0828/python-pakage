# -*- coding: utf-8 -*-

project = 'test'
master_doc = 'index'

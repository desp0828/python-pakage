:orphan:

.. _example_numpy:

Example NumPy Style Python Docstrings
======================================

.. seealso::

   :ref:`example_google`

.. only:: builder_html

   Download: :download:`example_numpy.py <example_numpy.py>`

.. literalinclude:: example_numpy.py
   :language: python

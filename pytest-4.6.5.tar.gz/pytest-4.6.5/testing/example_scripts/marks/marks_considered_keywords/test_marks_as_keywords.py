# -*- coding: utf-8 -*-
import pytest


@pytest.mark.foo
def test_mark():
    pass

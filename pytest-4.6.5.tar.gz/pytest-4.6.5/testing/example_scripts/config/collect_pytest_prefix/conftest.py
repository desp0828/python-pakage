# -*- coding: utf-8 -*-
class pytest_something(object):
    pass

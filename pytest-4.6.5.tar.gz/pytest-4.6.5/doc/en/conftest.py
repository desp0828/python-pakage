# -*- coding: utf-8 -*-
collect_ignore = ["conf.py"]
